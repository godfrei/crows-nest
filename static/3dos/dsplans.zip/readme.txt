THE DEATH STAR PLANS ARE NOT IN THE MAIN COMPUTER!
They're in this zip file in all their three dimensional glory.
These files have been designed for use in the upcoming Secbase contest at www.df-21.net 


dsplans1.3do - Death Star plans 3do
dsplans2.3do - Death Star plans 3do 0.5 scale
dsplans.bm - Death Star Plans texture, based on idplans.wax by Lucasarts.

Make sure you use thse 3dos in light areas. In dark areas the texture looks bad.

If you are using dsplans1.3do use this logic:
 
LOGIC:     PLANS
RADIUS: 1.5
HEIGHT: 1

If you are using dsplans2.3do use this logic:
 
LOGIC:     PLANS
RADIUS: 0.75
HEIGHT: 0.5


Designed by Barry Brien harachi@oceanfree.net
