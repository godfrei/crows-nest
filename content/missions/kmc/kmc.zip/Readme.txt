
IF YOU HAVE DOWNLOADED ANY OTHER LEVELS OR DATA FILES BACK THEM UP
THIS LEVEL REPLACES JABAS SHIP. AND THE DFBRIEF.LFD

copy/move the file LFD.EXE to the dark\lfd directory and execute.
copy/move the files kaleds.gob and play.bat to the dark directory and type play

================================================================
Title                   : Kyle meets Kaled
Filename                : Kaleds.GOB
Author                  : Troy Nathan Robeck
Email Address           : 100406.2653@compuserve.com
Misc. Author Info       : 

Description             : run around and destroy some daleks

Additional Credits to   :Yves BORCKMANS
			 All those who have made contributions
			 to help files and utilites for editing
			 who are WAY too numerous to mention.
================================================================

* Play Information *

Level replaced          : Jabas Ship
Difficulty Settings     : easy and Hard
New BMs                 : Yes
New FMEs                : No
New WAXs                : Yes
New 3DOs                : Yes
New VOCs                : Yes
New GMDs                : No

* Construction *

Base                    : New level from scratch/Modified levelname
Editor(s) used          : dfuse100
Known Bugs              : waterfall dosen't scroll
			  Too many 3do's in one room
			  sounds are jumpy
			  Waxes incomplete
			: crashes on completion
			: some elevators refuse to work 
 			  reguardless of editing

* Copyright / Permissions *

Authors may use this level as a base to build additional
levels.

You MAY distribute this GOB, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this GOB *

FTP sites:

BBS numbers:

Other: Compuserve at present.
