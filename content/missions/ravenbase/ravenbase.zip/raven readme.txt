================================================================
Title                   : Raven basr
Filename                : Future1.GOB, Future1.bat, and this file Future1.txt 
Author                  : Ross Sheddon
Email Address           : R_skywalker@yahoo.com

  
Description             : Kyle and Jan have discovered                           the Imperial Commando bace
                          on Desal. Whare the strongest                           and most eleit storm troopers                           go. the best become Imperial                           Gaurds. The troops have there                           own armour and veichels called                           s.H.V. which stands for                           Sheddon Hover Veichels.

                           But as Kyle lands on an                               asteroid just out side Desal                            whare he was to make a                                  operations bace for his mission
                         he relises how rong his reserch                          had been.... 
                          

**********Full details of the game are below: ********** 
			you finish the level!


Additional Credits to: To all the LucasArts team for a terrific game.
Keep up the good work and There going to make us MULTIPLAYER VERSION !(about time!)
All of the new stuff is mostly my creation. But Beta Level testing thanks
goes to:my self
   ================================================================

* Play Information *

Level(s) replaced       : SECBASE
Difficulty Settings     : No
New BMs                 : Yes
New FMEs                : Yes
New WAXs                : Yes
New 3DOs                : No
New VOCs                : Yes
New GMDs                : Yes 

* Construction *

Base                    : New level from scratch. (And what a scratch it was!)
Editor(s) used          : Wedit, FME, BMPBM 
Known Bugs              : one or two HOMs
			
* Copyright / Permissions *    (Boring stuff!!!)

Authors may NOT use this level as a base to build additional
levels. (But you can steal.. I mean, use any ideas from it.)  

You MAY distribute this GOB, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.
     *********Full Deatils of the level*********
You may have gest that the base was on the asteroid
