Instructions for using IMPERIAL PRISON ISLAND
=============================================

Installation
------------

The archive in wich Imperial Prison Island (IPI) is distributed, contains the 
following files:

--------------------------------------
 File         | Where to put this file    
--------------------------------------
 PRISON.BAT   | DARK
 PRISON_O.EXE | DARK
 PRISON_P.EXE | DARK
 PRISON.GOB   | DARK
 BRIEF.LFD    | LFD/DARK
 DOWN.LFD     | LFD/DARK
 FLY_AWAY.LFD | LFD/DARK
 FLY_BY.LFD   | LFD/DARK
 FLY_IN.LFD   | LFD/DARK
 INTRO.LFD    | LFD/DARK
 LANDING.LFD  | LFD/DARK
 PROBE.LFD    | LFD/DARK
 SCROLL.LFD   | LFD/DARK
 PRISON.TXT   | -
 README.TXT   | -
--------------------------------------

 The files marked as DARK should be placed in your main dark forces directory.

 Files marked as LFD/DARK should be placed in the directory where you have all
 your *.LFD files. If you have installed Dark Forces in a directory called 
 C:\DARK, the right directory to put the LFDs in may be C:\DARK\ or C:\DARK\LFD, 
 depending on how you installed Dark Forces. You will have to find the right
 directory yourself.

 Unmarked files, like this one, is uninportant, and can be deleted.

Runing the level
----------------
 
 To start the level, just type PRISON at the DOS prompt. 

 ******************************************************************************
  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!  OBS!
 ******************************************************************************

 You MUST use the PRISON.BAT-file to start the level. It's not enough just
 to type DARK -uPRISON.GOB - this will mess up the level!

--------------------
Good luck!