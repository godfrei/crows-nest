>>>>>     Modified DARK FORCES Mission 10 - Jabba's Ship    <<<<<
                                               Revenge
                    
THIS IS NOT A NEW MISSION !!!  IT IS A MODIFIED MISSION 10. 
All difficulty levels are the same - BRUTAL !! - If you can beat 
this mission without being laimlame, then you truly are -
<< THE KING OF ALL BOUNTY HUNTERS >> 

This zipfile consists of 4 files < JABSHIP.O > < READ_ME.TXT > 
and 2 PCX images. Only the first file (jabship.o) is neccessary to run 
this mission.

Copy this file to your Dark Forces directory < c:\dark >, then start 
the game as you normally would. Load Mission 10 < Jabba's Ship >, and 
the modified mission will begin. To restore the original mission 10, 
just delete the above file from the DF directory. It will not damage 
the original mission in any way.
_____________________________________________________________________

Briefing: 

During an attempt to bring Jabba the Hutt to justice, Jan, all your gear, 
and the Nava Card from your ship were captured. Now it's up to you to get 
your gear back, find the Nava Card and Rescue Jan. Be prepared for anything.
Jabba is aware of your abilities and will be expecting a rescue attempt. 

Our intelligence sources report that Jabba may have acquired advanced 
Imperial weapons technology, in return for smuggling supplies to the 
Empire's secret research and development facilities, under the direct
command of General Mohc. Extreme caution is advised.

Unconfirmed sources report that one or more Mandalorian Mercenaries may 
be working for Jabba at the present time. You are hereby authorized to 
terminate any Mercenaries that may be encountered, with extreme prejudice. 
( ......I'm not sure what that means, but it sounds cool ).

____________________________________________________________________


You'll need to find ALL the secrets to get through this mission. 
Good Luck!  (better download the FAQ List). 
Check out the PCX images. Use PAINTBRUSH or any PCX viewer.

E-Mail to << cmdrkrud@aol.com >>  << 72734,2553@compuserve.com >>

Upload this mission anywhere, anytime, anyway - as long as it's free. 
Use at your own risk.

Thanks to Don Sielke - Jedi Master - for the editing tips.
Thanks to Karsten Loepelmann for an excellent FAQ.
Thanks to LucasArts for a GREAT game. WE WANT MORE!!
____________________________________________________________________
                              
   