___STAR______________________________________________________________
/            ________      ______    ________    ____ _____           \
|            |       \     |    |    |       \   |   ||   |            |
|            |   __   \    |    |    |   __   \  |   ||   |            |
|            |   ||   |    | /\ |    |   ||   |  |   ||   |            |
|            |   ||   |   |  ||  |   |   ||   |  |   |/   |            |
|            |   ||   |   |  ||  |   |   ~`   /  |       /             |
|            |   ||   |   |  ||  |   |   /\   \  |   |\  \             |
|            |   ||   |  |   ~'   |  |   ||   |  |   ||   |            |
|            |   ~'   /  |   __   |  |   ||   |  |   ||   |            |
|            |_______/   |__/  \__|  |___||___|  |___||___|            |
| _________    ______    ________      ______    _________    ______   |
| |       |   /      \   |       \    /      \   |       |   /      \  |
| |   ____|  /   __   \  |   __   \  /   __   \  |   ____|  /   __   \ |
| |   |      |   ||   |  |   ||   |  |   ||   |  |   |      |   ||___| |
| |   |___   |   ||   |  |   ||   |  |   ||___|  |   |___   \_   \_    |
| |   ____|  |   ||   |  |   ~`   /  |   | ____  |   ____|    \_   \_  |
| |   |      |   ||   |  |   /\   \  |   ||   |  |   |      ____\,   \ |
| |   |      |   ||   |  |   ||   |  |   ||   |  |   |____  |   ||   | |
| |   |      \   ~'   /  |   ||   |  \   ~'   /  |       |  \   ~'   / |
| |___|       \______/   |___||___|   \______/   |_______|   \______/tm|
\______________________________________________________________    ___/
                                                               WARS

                         DARK FORCES: BFG PATCH
                         CREATED BY: LANE FERGUSON

THIS IS A PATCH FOR DARK FORCES.  THE PATCH WILL CHANGE THE 
CONCUSSION WEAPON(9) INTO THE BFG(BIG $#!@%*! GUN) WEAPON FROM DOOM.

TO INSTALL COPY THE BFG.EXE INTO YOUR DARK FORCES DIRECTORY.  ONCE 
FILE IS COPIED GOTO YOUR DARK FORCES DIRECTORY AND TYPE BFG.  THEN 
WHEN YOU LOAD DF THE CONCUSSION WEAPON WILL BE REPLACED WITH THE 
BFG GUN.

TO UNINSTALL THE BFG PATCH DELETE THE FILES THAT IT ADDED TO YOUR
DARK FORCES DIRECTORY.
        
           THE FILES ARE:

                        CONCUSS1.BM
                        CONCUSS2.BM
                        CONCUSS3.BM
                             
THIS IS MY FIRST PATCH THAT I AM UPLOADING.  YOU MAY UPLOAD THIS  
PATCH TO ANY SYSTEM YOU LIKE, AND GIVE IT TO AS MANY FRIENDS AS YOU
LIKE, AS LONG AS THIS README FILE IS INCLUDED WITH THE PATCH.

                        HAVE FUN!!!
