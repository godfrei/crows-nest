Jedi Master Joruus C'Baoth WAX
------------------------------

Author: Jeff Walters

As seen in the Dark Forces add-on mission "Mt. Kurek". Best used with Phase 3 Dark Trooper logic.

You may use this component in your own levels provided you give the author credit.

Extracted and repackaged by Geoff Elliott to keep the DF editing community alive. If you are the author and want the copyright notice modified or the component removed, please get in touch by visiting The Crow's Nest.
