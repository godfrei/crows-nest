                      * * * * * * * * * * * * * 
                     *   #### #####  ###  ####  *
                     *  #       #   #   # #   # *
                     *   ###    #   ##### ####  *
                     *      #   #   #   # #  #  *
                     *  ####    #   #   # #   # *
                     *                          *
                     *  # # #  ###  ####   #### *
                     *  # # # #   # #   # #     *
                     *  # # # ##### ####   ###  *
                     *  # # # #   # #  #      # *
                     *   # #  #   # #   # ####  *
                       * * * * * * * * * * * * * 

                    H I D D E N  J A W A  B A S E


   AFTER RESCUING R2D2, THE REBELLION SUSPECTS THAT THE PLANS TO THE 

DEATH STAR HAD BEEN REMOVED FROM THE DROID, AND KEPT BY THE JAWAS.  

YOUR MISSION IS TO GET THEM BACK, OF COURSE.

=======================================================================

CREDITS

The Jawa sounds and original Jawa used in this level have been taken from JAWAFULL.ZIP. 

The landspeeder used in the hangar, LARS.3DO, was created by Gary Belisle (Keemosabi@AOL.com), and the speederbikes were created by Marv Mays.

The creaking sound that bellows from the large doors was created by Lionel Fouillen.

All text files to these added files have been included.

=======================================================================

MY CREATIONS

The "officer" Jawa, with yellow stripes, and the Jawa with the concussion rifle were modified by me, John Teske (yes, you may use these, as long as credit is given to me and the original creators).

I also made a new briefing file, and a wall mural-thing, but why would anyone ever use those?

As for the "new", secret 0 gun, I made a minimal effort to make that.  All I wanted was a 0 gun that wouldn't take up the whole screen.  Yes, I know it's not centered, and its a little messed up, but I didn't want to take the effort to do anymore.

=======================================================================

TECH SPECS:

LEVELS REPLACED: SECBASE
DIFFICULTY SETTINGS: No
NEW BMs: Yes (1)
NEW FMEs: Yes (1)
NEW WAXes: Yes (2)
New 3DOs: No
New VOCs: No
New GMDs: No
New LFDs: Yes (1, breifing)
New VUEs: No
Base: New level from scratch
Editor(s) used: Wedit 3.2, Windows bitmap for new WAXes
Known Bugs: Jawas may "jump" and appear shorter and are not vulnerable.             Also, jawas may move into walls a tad.

=======================================================================

Jawa Secret Base by John Teske

astro_galileo_empire@yahoo.com