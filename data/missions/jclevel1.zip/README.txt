MISSION 1 of the Jedi Crystal Series

Sorry, Kyle, but our getaway on Ord Mantell has been cut short. It seems the higher rebel command has another job for us.

BACKGROUND

I'm not sure if you're aware of the legend of the Jedi Crystal, but there are rumors going around that it exists. The Jedi Crystal grants any user holding the crystal powers of a jedi far beyond the power of even Darth Vader. Its history goes back even before the time of the old republic, but it has never been proven to exist. However, recently, a mining facility on the planet Terrak VI unearthed an ancient citadel containing manuscripts of what appears to be writings about the Jedi Crystal. Unfortunately, General Merrik Ingram, an imperial commander is aware of this as well. And the empire didn't waste any time putting up a mobile research facility nearby the ruins. Even as we speak, the manuscripts are being translated and encoded to the facility's central mainframe. The rate of translation and how much of it has been translated is currently unknown at this time.

MISSION

The rebel high command is also aware of the crystal, and although it may be just a legend, they aren't going to take any chances, now that we are more vulnerable building a new base on Hoth. I'll be dropping you in a higher part of the mountains close to where the base is, but there is a high level of imperial sky patrols, so I'll have to drop you away from the ruins. From there you'll have to make your way down to the base on your own.

The base itself is mildly guarded, but that doesn't mean you can just walk through the front door. I did a diagnostic scan of the area and found the main cave nearby, along with small viens spreading out from it, I wouldn't be surprised if there was a small entry way near a river. Gain access to the base and find the main computer, make a copy of the information on a tape and leave with little evidence you were there. We need some hard evidence if this crystal even exists before we can take it seriously, so try not to make too big of a mess down there.

OBJECTIVES
- Make a copy of the Imperial Data
- Return to the Crow

Programs used:
- Dark Forge
- Adobe Photoshop 6
- DF BM Converter
- DF WAX/FME Converter
- Simpletext

Level: Made from scratch (replaces Secret Base)
New BMs: Yes
New WAXs: Yes
New 3DOs: Yes
New VOCs: No
New VUEs: No
New GMDs: No (Executor)
New FMEs: Yes

Comments: This is the first level of the Jedi Crystal series. I decided I wanted to make a series of levels, each showing at least something new. Although this level doesn't really have much new to offer, it still has its strong points from my view. It is relatively easy to complete and each skill level works out fine. I learned a lot from doing Spice Bust on Taloron, and although that level is pretty much dead, some of the implemations will live on in this series. Unfortunately, this will be the only level released until the rest of the levels are complete, but hopefully this teaser will put a spot on the map. All the other levels will include plenty of new innovations, many of which have already been done, but have been refined. Patience is a virtue though, but I'll be sure to create each level to the best of my ability. Now remember, this is not completely complete, it's just a playable version. There are some things that I will change and fix (like texturing and such) so there will be a few things that will not look right in certain areas. But I hope you enjoy this, because I worked really hard and I want you all to be pleased with my work. It's no Dark Tide, but it's still good.

Thanks, and enjoy
- James Milne (Burning Gundam)